using System.Drawing;

namespace EvolutionNet.Util.Imaging
{
	public class BitmapEx
	{
		private readonly Bitmap bitmap;

		public BitmapEx(Bitmap bitmap)
		{
			this.bitmap = bitmap;
		}
	}
}