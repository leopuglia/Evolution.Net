namespace EvolutionNet.MVP.Business
{
	public delegate void ActionDelegate();
}