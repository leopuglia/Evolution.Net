using EvolutionNet.MVP.Business;

namespace EvolutionNet.MVP.Business
{
	public interface INullContract : IContract
	{
	}
}