namespace EvolutionNet.MVP.Core.Contract
{
	public interface IDominioContract : IContract
	{
		void FindAllForEdit();
	}
}