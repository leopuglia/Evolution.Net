
namespace EvolutionNet.MVP.UI.Windows
{
	public partial class ModalDlgView : BaseFrmView
	{
		protected ModalDlgView()
		{
			InitializeComponent();
		}

	}
}