namespace EvolutionNet.MVP.Data.Definition
{
	public interface INullModel : IModel<object>
	{
	}
}