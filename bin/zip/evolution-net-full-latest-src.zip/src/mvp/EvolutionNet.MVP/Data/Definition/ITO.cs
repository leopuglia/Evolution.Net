namespace EvolutionNet.MVP.Data.Definition
{
	public interface ITO
	{
	}
}