namespace EvolutionNet.MVP.Data.Definition
{
	public class NullTO : ITO
	{
	}
}