using EvolutionNet.Util.IoC;

namespace EvolutionNet.MVP.Presenter
{
	public interface IPresenterFactory : IFactory
	{
	}
}