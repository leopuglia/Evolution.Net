using System;
using EvolutionNet.MVP.Business;
using EvolutionNet.MVP.View;
using EvolutionNet.Util.IoC;

namespace EvolutionNet.MVP.Presenter
{
	public abstract class BasePresenter<ViewT, ContractT> : IPresenter
		where ViewT : IView
		where ContractT : IContract
	{
		#region Vari�veis Locais

		private readonly ViewT view;
		private readonly ContractT facade;

		#endregion

		#region Propriedades Locais

		protected ViewT View
		{
			get { return view; }
		}

		protected ContractT Facade
		{
			get { return facade; }
		}

		#endregion

		#region Propriedades P�blicas

		public IHelperFactory HelperFactory
		{
			get { return View.HelperFactory; }
		}
		
		#endregion

		#region Construtores

		protected BasePresenter(ViewT view)
		{
			AbstractIoCFactory<IBusinessFactory>.Instance.Initialize();

			facade = GetFacade();

			this.view = view;
		}

		#endregion

		#region M�todos Locais

		private ContractT GetFacade()
		{
			try
			{
				return AbstractIoCFactory<IBusinessFactory>.Instance.GetFromContract<ContractT>(this);
			}
			catch (Exception ex)
			{
				throw new MVPIoCException("Error creating the ICrudContract implementation no Presenter.", ex);
			}
		}

		#endregion

	}
}
