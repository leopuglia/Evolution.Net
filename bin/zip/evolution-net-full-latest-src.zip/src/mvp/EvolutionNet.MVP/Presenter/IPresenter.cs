using EvolutionNet.MVP.View;

namespace EvolutionNet.MVP.Presenter
{
	public interface IPresenter
	{
		IHelperFactory HelperFactory { get; }
//		IPathHelper PathHelper { get; }
//		IControlHelper ControlHelper { get; }
//		IMessageHelper MessageHelper { get; }
	}
}