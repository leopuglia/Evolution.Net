using EvolutionNet.MVP.View;

namespace EvolutionNet.MVP.Presenter
{
	public interface IPresenter
	{
		IPathHelper PathHelper { get; }
	}
}