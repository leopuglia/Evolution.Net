namespace EvolutionNet.MVP.View
{
	public interface IWebControl
	{
		bool IsPostBack { get; }
	}
}