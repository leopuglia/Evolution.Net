using System;

namespace EvolutionNet.MVP.View
{
	public class CrudEventArgs : EventArgs
	{
		private int rowIndex = -1;

		public int RowIndex
		{
			get { return rowIndex; }
			set { rowIndex = value; }
		}

		public CrudEventArgs()
			: this(-1)
		{
		}

		public CrudEventArgs(int rowIndex)
		{
			this.rowIndex = rowIndex;
		}
	}

}