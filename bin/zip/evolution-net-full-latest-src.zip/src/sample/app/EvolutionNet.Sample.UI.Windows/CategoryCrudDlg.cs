﻿using EvolutionNet.MVP.UI.Windows;

namespace EvolutionNet.Sample.UI.Windows
{
	public partial class CategoryCrudDlg : BaseFrmView
	{
		public CategoryCrudDlg()
		{
			InitializeComponent();

			baseUC = categoryCrudView1;
		}
	}
}
