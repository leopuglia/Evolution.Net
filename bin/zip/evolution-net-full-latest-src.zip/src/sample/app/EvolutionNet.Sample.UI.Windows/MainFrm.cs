﻿using EvolutionNet.MVP.UI.Windows;

namespace EvolutionNet.Sample.UI.Windows
{
	public partial class MainFrm : BaseFrmView
	{
		public MainFrm()
		{
			InitializeComponent();

			baseUC = mainView1;
		}

	}
}
