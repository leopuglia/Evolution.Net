﻿using System;
using EvolutionNet.MVP.UI.Web;

namespace EvolutionNet.Sample.UI.Web
{
	public partial class _Default : BasePageView
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}
	}
}
