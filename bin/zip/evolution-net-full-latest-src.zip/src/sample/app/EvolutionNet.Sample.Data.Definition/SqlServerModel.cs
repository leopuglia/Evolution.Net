namespace EvolutionNet.Sample.Data.Definition
{
	public abstract class SqlServerModel
	{
	}
}