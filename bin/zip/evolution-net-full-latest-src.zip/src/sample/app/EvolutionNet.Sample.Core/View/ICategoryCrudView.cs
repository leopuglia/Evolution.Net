using EvolutionNet.MVP.View;
using EvolutionNet.Sample.Data.Definition;

namespace EvolutionNet.Sample.Core.View
{
	public interface ICategoryCrudView : ICrudView
	{
//		bool ShowEditModalDlg(Category category);
	}
}