using EvolutionNet.MVP.Business;

namespace EvolutionNet.Sample.Core.Business
{
	public interface IMainContract : IContract
	{
	}
}