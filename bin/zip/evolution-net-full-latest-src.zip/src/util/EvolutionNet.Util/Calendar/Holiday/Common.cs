﻿using System;

namespace EvolutionNet.Util.Calendar.Holiday
{
	public static class Common
	{
		public static DateTime GetNewYearDayDate(int year)
		{
			return new DateTime(year, 1, 1);
		}

	}
}
