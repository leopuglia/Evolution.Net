﻿namespace EvolutionNet.Util.Calendar.Holiday.Country.Localized.EnUs
{
	public class National : Us.National
	{
		public National(int year) : base(year)
		{
		}
	}
}