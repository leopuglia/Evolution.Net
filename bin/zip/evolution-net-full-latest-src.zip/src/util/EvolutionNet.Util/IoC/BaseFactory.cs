namespace EvolutionNet.Util.IoC
{
	public abstract class BaseFactory : IFactory
	{
	}
}
