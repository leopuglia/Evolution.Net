/*
 * Created by: 
 * Created: quinta-feira, 6 de dezembro de 2007
 */

namespace EvolutionNet.Util.IoC
{
	/// <summary>
	/// Interface que define uma implementa��o de factory b�sica.
	/// </summary>
	public interface IFactory
	{
	}
}