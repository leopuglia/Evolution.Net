﻿namespace EvolutionNet.Util.Calendar.Holiday
{
	public enum HolidayType
	{
		NationalHoliday,
		NationalHolidayAlias,
		StateHoliday,
		CommemorativeDay,
		OptionalLaborDay
	}
}
