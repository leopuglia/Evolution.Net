namespace EvolutionNet.MVP.Core.Data.Definition
{
	public interface IDominioModel : IModel<short>
	{
//		string Nome { get; set; }
//		string Descricao { get; set; }
//		bool Visivel { get; set; }
	}
}