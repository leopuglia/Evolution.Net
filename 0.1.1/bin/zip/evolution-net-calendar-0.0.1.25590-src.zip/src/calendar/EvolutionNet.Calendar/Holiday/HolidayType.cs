﻿namespace EvolutionNet.Calendar.Holiday
{
	public enum HolidayType
	{
		NationalHoliday,
		NationalHolidayAlias,
		CommemorativeDay,
		OptionalLaborDay
	}
}
