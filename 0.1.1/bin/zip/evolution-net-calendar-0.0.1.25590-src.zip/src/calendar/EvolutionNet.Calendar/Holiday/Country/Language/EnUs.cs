﻿using System;

namespace EvolutionNet.Calendar.Holiday.Country.Language
{
	public class EnUs : Us
	{
		public EnUs(int year) : base(year)
		{
		}
	}
}
